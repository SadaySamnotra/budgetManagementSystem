document.getElementById('navbar-toggle').addEventListener('click', function() {
    const navbarCollapse = document.getElementById('navbar-collapse');
    navbarCollapse.classList.toggle('active');
});
